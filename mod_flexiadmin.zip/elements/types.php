<?php
	//Get FC Types of Content Helper
	require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_flexicontent'.DS.'elements'.DS.'types.php');
?>